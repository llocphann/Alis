// Conservative deep-interior guard for the existing d > 24 shader exit.
// Inputs are already packed float uniforms, not a second traversal of records.
// No state/cache, approximation of the contour, changed wave or material math.
function bounds(viewport,insets,material,rectangles,radii,waveMaterial,contact,contactNormal,ripple,rippleNormal,scale) {
    var disabled=[0,0,0,0];
    var vectors=[viewport,insets,material,waveMaterial,contact,contactNormal,ripple,rippleNormal];
    for(var v=0;v<vectors.length;v++) {
        var value=vectors[v];
        if(!Number.isFinite(value.x)||!Number.isFinite(value.y)||!Number.isFinite(value.z)||!Number.isFinite(value.w))return disabled;
    }
    var width=viewport.x,height=viewport.y,radius=material.x,k=Math.max(.1,material.y);
    if(width<=0||height<=0||width>32768||height>32768||radius<0||radius>32768||material.y<0||material.y>32768
            ||!Number.isFinite(scale)||scale<=0)return disabled;
    // Each primitive exceeds L in the returned rectangle. The smooth-min
    // recurrence preserves d >= L-k regardless of slot count: if a >= L-k
    // and b >= L, min(a,b)-max(k-|a-b|,0)^2/(4k) >= L-k.
    // Add a numerical reserve and a full derivative quad at this render scale.
    var reach=24+k+8+4/Math.min(1,scale);
    // Every encoded RG wave sample is within [0,256]. Monotone Hermite and
    // positive normalized corner weights cannot exceed that bound. It is
    // independent of asynchronous Canvas/texture updates and crest decay.
    if(waveMaterial.y>=.5&&waveMaterial.x>=1) {
        // Unknown texture formats retain the original complete shader path.
        if(!(waveMaterial.w>0))return disabled;
        reach+=waveMaterial.w+1;
    }
    if(contact.w>.001)reach+=18*Math.abs(contact.z)*contact.w;
    if(ripple.w>.001&&ripple.z<1)reach+=23.04*Math.max(.1,rippleNormal.z)*ripple.w*Math.pow(1-ripple.z,1.5);
    if(!Number.isFinite(reach))return disabled;
    // Protect every physical-contact corner, including contacts at 0px Edges.
    var left=Math.max(0,insets.x)+radius+reach,top=Math.max(0,insets.y)+radius+reach;
    var right=Math.max(0,insets.z)+radius+reach,bottom=Math.max(0,insets.w)+radius+reach;
    for(var i=0;i<rectangles.length;i++) {
        var rect=rectangles[i],rounding=radii[i];
        if(rect.z<=0||rect.w<=0)continue;
        if(!Number.isFinite(rect.x)||!Number.isFinite(rect.y)||!Number.isFinite(rect.z)||!Number.isFinite(rect.w)
                ||Math.abs(rect.x)>32768||Math.abs(rect.y)>32768||rect.z>32768||rect.w>32768
                ||!Number.isFinite(rounding)||Math.abs(rounding)>32768)return disabled;
        // An arbitrary rectangle is assigned to the cheapest covering strip;
        // no assumption that floating/large bodies actually touch that Edge.
        var depths=[Math.max(0,rect.x+rect.z),Math.max(0,rect.y+rect.w),Math.max(0,width-rect.x),Math.max(0,height-rect.y)];
        var side=0;
        for(var j=1;j<4;j++)if(depths[j]<depths[side])side=j;
        if(side===0)left=Math.max(left,depths[0]+reach);
        else if(side===1)top=Math.max(top,depths[1]+reach);
        else if(side===2)right=Math.max(right,depths[2]+reach);
        else bottom=Math.max(bottom,depths[3]+reach);
    }
    if(left+right>=width||top+bottom>=height)return disabled;
    return [left,top,width-right,height-bottom];
}
