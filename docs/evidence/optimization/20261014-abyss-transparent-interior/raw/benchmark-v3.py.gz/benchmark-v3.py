from pathlib import Path
import tempfile,subprocess,os,json,time,re,signal,hashlib
from PIL import Image
ROOT=Path(__file__).resolve().parents[3]
BASE=Path(__file__).resolve().parent
OUT=BASE/'benchmark-v3';OUT.mkdir(exist_ok=True)
HZ=os.sysconf('SC_CLK_TCK')
def metrics(pid):
 p=Path('/proc')/str(pid);a=(p/'stat').read_text().split(') ',1)[1].split();clients={}
 for fd in (p/'fdinfo').iterdir():
  try:text=fd.read_text()
  except OSError:continue
  client=re.search(r'^drm-client-id:\s*(\d+)',text,re.M);gpu=re.search(r'^drm-engine-gfx:\s*(\d+) ns',text,re.M)
  if client and gpu:clients[client[1]]=max(clients.get(client[1],0),int(gpu[1]))
 mem=(p/'smaps_rollup').read_text();pss=re.search(r'^Pss:\s*(\d+)',mem,re.M)
 return {'time':time.monotonic(),'cpu_seconds':(int(a[11])+int(a[12]))/HZ,'gfx_ns':sum(clients.values()),'gpu_clients':clients,'pss_kib':int(pss[1])}
def target(parent):
 descendants={parent}
 for _ in range(4):
  for p in Path('/proc').iterdir():
   if not p.name.isdigit():continue
   try:
    a=(p/'stat').read_text().split(') ',1)[1].split()
    if int(a[1])in descendants:descendants.add(int(p.name))
   except (OSError,ValueError):pass
 for pid in descendants:
  try:
   if Path(os.readlink('/proc/'+str(pid)+'/exe')).name in ['qs','quickshell']:return pid
  except OSError:pass
 return None
rows=[]
for count,active in [(4,False),(16,False),(40,False),(16,True)]:
 for repeat in range(4):
  for mode in (['before','after'] if repeat%2==0 else ['after','before']):
   label=f'{count}-{int(active)}-{repeat}-{mode}';out=OUT/label;out.mkdir(exist_ok=True)
   with tempfile.TemporaryDirectory(prefix='alis-field-clearance-bench-')as name:
    folder=Path(name);variants=folder/'variants';variants.mkdir()
    for entry in ['modules','services','GlobalStates.qml','qmldir','assets','scripts','defaults','translations']:(folder/entry).symlink_to(ROOT/entry)
    for label_field,filename in [('OriginalField','reference.qml'),('CandidateField','CandidateField.qml')]:
     text=(BASE/filename).read_text().replace('import qs.services','import qs.services\nimport qs.modules.abyss.looks')
     old='readonly property string wallpaperUrl: wantsWallpaper\n        ? WallpaperListener.wallpaperUrlForScreen(root.Window.window?.screen ?? null) : ""'
     assert old in text
     text=text.replace(old,'readonly property string wallpaperUrl:Qt.resolvedUrl("fixture.png")')
     (variants/(label_field+'.qml')).write_text(text)
    for source,name_qsb in [('reference.frag.qsb','AbyssField.frag.qsb'),('CandidateField.frag.qsb','CandidateField.frag.qsb'),('AbyssTransparentInterior.js','AbyssTransparentInterior.js')]:
     (variants/name_qsb).write_bytes((BASE/source).read_bytes())
    (variants/'AbyssGeometry.js').symlink_to(ROOT/'modules/abyss/looks/AbyssGeometry.js')
    image=Image.new('RGB',(160,100));image.putdata([(x*255//159,y*255//99,(x*7+y*3)%256)for y in range(100)for x in range(160)]);image.save(variants/'fixture.png')
    import math
    image=Image.new('RGBA',(128,1));pixels=[]
    for i in range(128):
     v=round((6+3*math.sin(i*.23))/256*65535);pixels.append((v>>8,v&255,50,255))
    image.putdata(pixels);image.save(folder/'wave.png')
    program=r"""
pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Window
import QtTest
import Quickshell
import qs.modules.common
import "variants"
ShellRoot {
 id:root;property bool active:false;property int frames:0;property var records:[];property int ticks:0
 Component.onCompleted:Quickshell.watchFiles=false
 Image {id:wave;width:128;height:1;source:"wave.png";visible:false;property bool activeProfile:__ACTIVE__;property real encodedHeightCeiling:256}
 FloatingWindow {id:win;visible:true;implicitWidth:2560;implicitHeight:1440;color:"#111820"
  Loader {id:field;anchors.fill:parent;source:"variants/__FIELD__.qml";onLoaded:{item.waveTexture=wave;item.edgeInsets={left:8,top:48,right:8,bottom:8}}}
 }
 Connections {target:field.item?.Window.window ?? null;function onFrameSwapped(){if(root.active)root.frames++}}
 FrameAnimation {running:true;onTriggered:{
  let records=[],offset=Math.sin(root.ticks*.07)*3
  for(let i=0;i<__COUNT__;i++){
   const edge=i%4,along=100+(i%7)*250
   const surface=edge===0?{x:along+offset,y:-50,width:160,height:150}:edge===2?{x:along+offset,y:1340,width:160,height:150}:edge===3?{x:-50,y:along+offset,width:150,height:160}:{x:2460,y:along+offset,width:150,height:160}
   records.push({surface:surface,radius:29})
  }
  root.records=records;root.ticks++;if(field.item)field.item.records=root.records
 }}
 TestCase {id:test;when:false;optional:true
  function run(){try{
   tryCompare(Config,"ready",true,5000)
   Config.setNestedValues({"performance.reduceAnimations":true,"abyss.quality":"quality","abyss.autoQuality":false})
   tryVerify(()=>field.item?.ready&&field.item.wallpaperReady,5000)
   let captured=false
   verify(field.item.grabToImage(result=>{verify(result.saveToFile(Quickshell.env("BENCH_OUTPUT")+"/warm.png"));captured=true}))
   tryVerify(()=>captured,5000);wait(1500)
   root.frames=0;root.active=true;console.info("CLEARANCE_BENCH_START")
   wait(5000);root.active=false
   console.info("CLEARANCE_BENCH_END",JSON.stringify({frames:root.frames,ticks:root.ticks,api:field.item.GraphicsInfo.api}))
   wait(250)
  }catch(e){console.error("CLEARANCE_BENCH_FAIL",e.message,e.stack)}Qt.quit()}
 }
 Timer {interval:100;running:true;onTriggered:test.run()}
}
"""
    (folder/'shell.qml').write_text(program.replace('__COUNT__',str(count)).replace('__ACTIVE__','true'if active else'false').replace('__FIELD__','OriginalField'if mode=='before'else'CandidateField'))
    env=dict(os.environ,BENCH_OUTPUT=str(out.resolve()),QT_QPA_PLATFORM='offscreen',QT_QUICK_BACKEND='rhi',QSG_RHI_BACKEND='opengl',QT_SCALE_FACTOR='1',QT_NO_XDG_DESKTOP_PORTAL='1')
    for key in ['QS_CONFIG_PATH','QS_CONFIG_NAME','QS_MANIFEST','NIRI_SOCKET']:env.pop(key,None)
    for key in ['config','state','cache','data','runtime']:
     path=folder/key;path.mkdir(mode=0o700);env['XDG_'+key.upper()+('_DIR'if key=='runtime'else'_HOME')]=str(path)
    cfg=folder/'config/alis';cfg.mkdir();(cfg/'config.json').write_text((ROOT/'defaults/config.json').read_text())
    log=out/'native.txt'
    with log.open('wb')as stream:proc=subprocess.Popen(['dbus-run-session','--','qs','-p',str(folder),'--no-color'],env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    before=after=None;pid=None;deadline=time.monotonic()+30
    try:
     while proc.poll()is None and time.monotonic()<deadline:
      if pid is None:pid=target(proc.pid)
      text=log.read_text()
      if 'CLEARANCE_BENCH_START'in text and before is None and pid:before=metrics(pid)
      if 'CLEARANCE_BENCH_END'in text and after is None and pid:after=metrics(pid)
      time.sleep(.01)
     if proc.poll()is None:os.killpg(proc.pid,signal.SIGTERM);proc.wait(5)
     text=log.read_text();match=re.search(r'CLEARANCE_BENCH_END (\{.+\})',text)
     warm=Image.open(out/'warm.png').convert('RGBA');nonzero=sum(warm.getchannel('A').histogram()[1:]);assert nonzero>10000,('empty renderer',nonzero)
     row={'nonzero_alpha_pixels':nonzero,'label':label,'count':count,'wave_active':active,'mode':mode,'repeat':repeat,'exit':proc.returncode,'before':before,'after':after,'native':json.loads(match[1])if match else None}
     if before and after and row['native'] and row['native']['frames']>0:
      row['cpu_seconds']=after['cpu_seconds']-before['cpu_seconds'];row['gfx_ms']=(after['gfx_ns']-before['gfx_ns'])/1e6;row['gfx_ms_per_frame']=row['gfx_ms']/row['native']['frames'];row['cpu_ms_per_frame']=row['cpu_seconds']*1000/row['native']['frames'];row['elapsed']=after['time']-before['time'];row['pss_kib']=after['pss_kib']
     (out/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row);(OUT/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
     print(label,json.dumps({k:row.get(k)for k in ['exit','gfx_ms_per_frame','cpu_ms_per_frame','pss_kib']}),flush=True)
     assert proc.returncode==0 and row.get('gfx_ms',0)>0 and 'CLEARANCE_BENCH_FAIL'not in text,row
    finally:
     if proc.poll()is None:os.killpg(proc.pid,signal.SIGTERM);proc.wait(5)