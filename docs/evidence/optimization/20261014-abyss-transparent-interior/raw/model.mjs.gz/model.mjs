
import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
const base=new URL('./',import.meta.url),root=new URL('../../../',base);
const interior=vm.runInNewContext(fs.readFileSync(new URL('AbyssTransparentInterior.js',base),'utf8')+';({bounds})');
const geometry=vm.runInNewContext(fs.readFileSync(new URL('modules/abyss/looks/AbyssGeometry.js',root),'utf8')+';({roundedDistance,physicalContactDistance,smoothUnion})');
const vec=(x=0,y=0,z=0,w=0)=>({x,y,z,w});
let seed=1234056789;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};
let cases=0,points=0,skipped=0,minimum=Infinity;const examples=[];
for(let scene=0;scene<2400;scene++){
 const width=[640,1280,1920,2560,3840][scene%5],height=[360,720,1080,1440,2160][scene%5];
 const insets=vec(...Array.from({length:4},()=>[0,.0005,8,16,60][Math.floor(random()*5)]));
 const radius=[0,12,29,64,256][scene%5],k=[.1,8,22,64,128][(scene+1)%5];
 const viewport=vec(width,height),material=vec(radius,k,12,.45),active=scene%3===0;
 const wave=vec(128,active?1:0,1,256);
 const contact=scene%7===0?vec(random()*width,random()*height,random()*2,.8):vec();
 const contactNormal=vec(0,1,scene%2,0);
 const ripple=scene%11===0?vec(random()*width,random()*height,random(),.8):vec(0,0,1,0);
 const rippleNormal=vec(0,1,random()*2,0);
 const rectangles=[],radii=[];
 for(let i=0;i<scene%41;i++){
  const along=random()*(i%2?width:height),depth=20+random()*100,span=40+random()*250;
  let record=i%4===0?vec(along,-50,span,depth+50):i%4===1?vec(width-depth,along,depth+50,span):i%4===2?vec(along,height-depth,span,depth+50):vec(-50,along,depth+50,span);
  if(scene%17===0)record=vec(random()*width,random()*height,50+random()*300,50+random()*300);
  if(scene%31===0)record=vec(-50,-50,width+100,height*.8);
  rectangles.push(record);radii.push([-10,0,12,29,64,256][i%6]);
 }
 const bound=interior.bounds(viewport,insets,material,rectangles,radii,wave,contact,contactNormal,ripple,rippleNormal,[.5,1,1.5,2][scene%4]);cases++;
 if(!(bound[2]>bound[0]&&bound[3]>bound[1])){skipped++;continue;}
 if(scene<12)examples.push({width,height,active,records:rectangles.length,bounds:Array.from(bound),interior_fraction:(bound[2]-bound[0])*(bound[3]-bound[1])/(width*height)});
 const motion=(active?257:0)+(contact.w>.001?18*Math.abs(contact.z)*contact.w:0)+(ripple.w>.001&&ripple.z<1?23.04*Math.max(.1,rippleNormal.z)*ripple.w*Math.pow(1-ripple.z,1.5):0);
 const hole={x:insets.x>=.001?insets.x:-64,y:insets.y>=.001?insets.y:-64,width:width-(insets.x>=.001?insets.x:-64)-(insets.z>=.001?insets.z:-64),height:height-(insets.y>=.001?insets.y:-64)-(insets.w>=.001?insets.w:-64)};
 for(let sample=0;sample<50;sample++){
  // Include points immediately adjacent to each proposed rejection boundary.
  const fx=sample%10===0?.000001:sample%10===1?.999999:random();
  const fy=sample%10===2?.000001:sample%10===3?.999999:random();
  const x=bound[0]+(bound[2]-bound[0])*fx,y=bound[1]+(bound[3]-bound[1])*fy;
  let d=-geometry.roundedDistance(x,y,hole,radius);
  for(let i=0;i<rectangles.length;i++){
   const r=rectangles[i],rect={x:r.x,y:r.y,width:r.z,height:r.w};
   const sdf=Math.min(geometry.roundedDistance(x,y,rect,radii[i]),geometry.physicalContactDistance(x,y,width,height,rect,radius,[true,true,true,true],radii[i]));
   d=geometry.smoothUnion(d,sdf,k);
  }
  minimum=Math.min(minimum,d-motion);points++;
  assert.ok(d-motion>24,JSON.stringify({scene,x,y,bound,d,motion}));
 }
}
const defaultViewport=vec(1920,1080),defaultInsets=vec(8,48,8,8),material=vec(29,22,29,.45),none=vec(),ripple=vec(0,0,1,0);
const defaultBound=interior.bounds(defaultViewport,defaultInsets,material,[],[],none,none,none,ripple,none,1);
assert.ok(defaultBound[2]>defaultBound[0]);
for(const invalid of [NaN,Infinity,-Infinity]){
 assert.deepEqual(Array.from(interior.bounds(vec(invalid,1080),defaultInsets,material,[],[],none,none,none,ripple,none,1)),[0,0,0,0]);
 assert.deepEqual(Array.from(interior.bounds(defaultViewport,defaultInsets,material,[vec(invalid,0,20,20)],[29],none,none,none,ripple,none,1)),[0,0,0,0]);
}
assert.deepEqual(Array.from(interior.bounds(defaultViewport,defaultInsets,material,[],[],vec(128,1,1,0),none,none,ripple,none,1)),[0,0,0,0],'unknown active wave texture must disable guard');
const result={cases,points,disabled_scenes:skipped,min_remaining_distance:minimum,examples,default:{bounds:Array.from(defaultBound),interior_fraction:(defaultBound[2]-defaultBound[0])*(defaultBound[3]-defaultBound[1])/(1920*1080)},scope:'Pure model only; no native/strict GPU acceptance or resource percentage'};
fs.writeFileSync(new URL('model-result.json',base),JSON.stringify(result,null,2)+'\n');console.log('CLEARANCE_MODEL_PASS',JSON.stringify(result));
