from pathlib import Path
import tempfile,subprocess,os,json,sys
ROOT=Path(__file__).resolve().parents[3];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from native_test_session import run_qs
with tempfile.TemporaryDirectory(prefix='alis-clearance-dependencies-')as name:
 folder=Path(name);variants=folder/'variants';variants.mkdir()
 for entry in ['modules','services','GlobalStates.qml','qmldir','assets','scripts','defaults','translations']:(folder/entry).symlink_to(ROOT/entry)
 text=(BASE/'CandidateField.qml').read_text().replace('import qs.services','import qs.services\nimport qs.modules.abyss.looks')
 old='readonly property string wallpaperUrl: wantsWallpaper\n        ? WallpaperListener.wallpaperUrlForScreen(root.Window.window?.screen ?? null) : ""'
 text=text.replace(old,'readonly property string wallpaperUrl:""')
 (variants/'CandidateField.qml').write_text(text)
 for file in ['CandidateField.frag.qsb','AbyssTransparentInterior.js']:(variants/file).write_bytes((BASE/file).read_bytes())
 (variants/'AbyssGeometry.js').symlink_to(ROOT/'modules/abyss/looks/AbyssGeometry.js')
 (folder/'shell.qml').write_text(r"""
pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Window
import QtTest
import Quickshell
import qs.modules.common
import "variants"
import "variants/AbyssTransparentInterior.js" as Interior
ShellRoot {
 id:root;property int checks:0;property bool waveOn:false;property real ceiling:256
 property vector4d contact:Qt.vector4d(0,0,0,0);property vector4d ripple:Qt.vector4d(0,0,1,0)
 Item {id:wave;width:128;property bool activeProfile:root.waveOn;property real encodedHeightCeiling:root.ceiling}
 QtObject {id:water;property vector4d contact:root.contact;property vector4d contactNormal:Qt.vector4d(0,1,1,0);property vector4d ripple:root.ripple;property vector4d rippleNormal:Qt.vector4d(0,1,1,0)}
 FloatingWindow {visible:true;implicitWidth:1920;implicitHeight:1080;color:"#111820"
  CandidateField {id:field;width:1920;height:1080;waveTexture:wave;waterLink:water}
 }
 TestCase {id:test;when:false;optional:true
  function check(ok,msg){root.checks++;if(!ok)throw new Error(msg)}
  function current(){
   const pass=field.children.find(c=>c.fragmentShader!==undefined)
   const rects=[],radii=[]
   for(let i=0;i<40;i++){rects.push(pass["rect"+i]);radii.push(pass["radii"+Math.floor(i/4)]["xyzw"[i%4]])}
   const values=Interior.bounds(pass.viewport,pass.insets,pass.material,rects,radii,pass.waveMaterial,pass.liquidContact,pass.liquidContactNormal,pass.liquidRipple,pass.liquidRippleNormal,field.renderScale)
   const expected=Qt.vector4d(values[0],values[1],values[2],values[3]),actual=pass.transparentInterior
   for(const key of ["x","y","z","w"])check(Object.is(actual[key],expected[key]),"stale uniform "+key+" actual "+actual+" expected "+expected)
   return actual
  }
  function run(){try{
   tryCompare(Config,"ready",true,5000);tryVerify(()=>field.ready,5000)
   Config.setNestedValues({"performance.reduceAnimations":true,"abyss.autoQuality":false,"abyss.quality":"quality"})
   for(let epoch=0;epoch<160;epoch++){
    let records=[]
    for(let i=0;i<epoch%41;i++){
     const edge=i%4,along=30+(i%6)*220,depth=48+(epoch%4)*20
     const rect=edge===0?{x:along,y:-50,width:160,height:depth+50}:edge===1?{x:field.width-depth,y:along,width:depth+50,height:160}:edge===2?{x:along,y:field.height-depth,width:160,height:depth+50}:{x:-50,y:along,width:depth+50,height:160}
     records.push({surface:rect,radius:[0,12,29,64][epoch%4]})
    }
    field.records=records;field.width=[1280,1920,2560][epoch%3];field.height=[720,1080,1440][epoch%3]
    field.renderScale=[.5,1,1.5,2][epoch%4]
    field.edgeInsets={left:epoch%2?0:8,top:epoch%3?48:0,right:epoch%2?0:16,bottom:epoch%3?8:0}
    root.waveOn=epoch%3===0;root.ceiling=epoch%11===0?0:256
    root.contact=epoch%7===0?Qt.vector4d(100,0,1,.8):Qt.vector4d(0,0,0,0)
    root.ripple=epoch%5===0?Qt.vector4d(100,0,.4,.8):Qt.vector4d(0,0,1,0)
    Config.setNestedValues({"abyss.perimeter.radius":[12,34,64][epoch%3],"abyss.surface.softness":[4,24,48][epoch%3]})
    wait(8);const actual=current()
    if(root.waveOn&&root.ceiling===0)check(actual.z===0&&actual.w===0,"unknown wave provider enabled guard")
   }
   field.records=[{surface:{x:40000,y:0,width:100,height:100},radius:29}];wait(8)
   const invalid=current();check(invalid.z===0&&invalid.w===0,"large-coordinate fallback changed")
   console.info("CLEARANCE_DEPENDENCY_PASS",root.checks,"checks/160 epochs; same live Field object, geometry/radius/scale/wave/contact changes")
  }catch(e){console.error("CLEARANCE_DEPENDENCY_FAIL",e.message,e.stack)}Qt.quit()}
 }
 Timer {interval:100;running:true;onTriggered:test.run()}
}
""")
 env=dict(os.environ,QT_QPA_PLATFORM='offscreen',QT_QUICK_BACKEND='rhi',QSG_RHI_BACKEND='opengl',QT_NO_XDG_DESKTOP_PORTAL='1')
 for key in ['QS_CONFIG_PATH','QS_CONFIG_NAME','QS_MANIFEST','NIRI_SOCKET']:env.pop(key,None)
 for key in ['config','state','cache','data']:
  path=folder/key;path.mkdir();env['XDG_'+key.upper()+'_HOME']=str(path)
 cfg=folder/'config/alis';cfg.mkdir();(cfg/'config.json').write_text((ROOT/'defaults/config.json').read_text())
 result=run_qs(folder,env,45);(BASE/'dependency-native.txt').write_text(result.stdout)
 assert result.returncode==0 and 'CLEARANCE_DEPENDENCY_PASS' in result.stdout and not any(token in result.stdout for token in ['CLEARANCE_DEPENDENCY_FAIL','ReferenceError:','TypeError:','Binding loop','Failed to compile shader']),result.stdout
 print(result.stdout)
