import subprocess,json,time
from pathlib import Path
b=Path('.git/maintainer-validation/20261014-abyss-transparent-interior')
commands=[('product-dark15', ['python3', 'scripts/test-abyss-transparent-interior-runtime.py', '--scale', '1.5', '--output', '.git/maintainer-validation/20261014-abyss-transparent-interior/product-dark15']), ('product-light1', ['python3', 'scripts/test-abyss-transparent-interior-runtime.py', '--light', '--output', '.git/maintainer-validation/20261014-abyss-transparent-interior/product-light1']), ('product-light15', ['python3', 'scripts/test-abyss-transparent-interior-runtime.py', '--light', '--scale', '1.5', '--output', '.git/maintainer-validation/20261014-abyss-transparent-interior/product-light15']), ('product-benchmark', ['python3', '.git/maintainer-validation/20261014-abyss-transparent-interior/product-benchmark.py']), ('ordered-fold', ['python3', 'scripts/test-abyss-field-support-runtime.py', '--output', '.git/maintainer-validation/20261014-abyss-transparent-interior/product-ordered-fold']), ('shader-lifecycle', ['bash', 'scripts/test-abyss-shader-lifecycle.sh']), ('wave-runtime', ['bash', 'scripts/test-abyss-wave-runtime.sh'])]
rows=[]
for label,cmd in commands:
 start=time.monotonic()
 with (b/(label+'.stdout.txt')).open('wb')as stream:r=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,timeout=480)
 row={'label':label,'command':cmd,'exit':r.returncode,'seconds':time.monotonic()-start};rows.append(row)
 (b/'product-qualification.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
