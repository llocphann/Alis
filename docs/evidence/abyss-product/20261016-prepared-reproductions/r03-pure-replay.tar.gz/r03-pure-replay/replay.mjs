import fs from 'node:fs';
import vm from 'node:vm';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

const [repo, output, expectedHead] = process.argv.slice(2);
if (!repo || !output?.startsWith('/tmp/') || !expectedHead)
  throw new Error('usage: node replay.mjs ABS_REPO NEW_TMP_OUTPUT EXPECTED_HEAD');
const git = (...args) => execFileSync('git', ['-C', repo, ...args], {encoding:'utf8'});
const hash = data => crypto.createHash('sha256').update(data).digest('hex');
const head = git('rev-parse', 'HEAD').trim();
if (head !== expectedHead || git('branch', '--show-current').trim() !== 'dev')
  throw new Error(`expected dev/${expectedHead}; actual HEAD=${head}`);
const sourcePath = 'modules/abyss/looks/AbyssLayout.js';
const historicalPath = 'docs/evidence/abyss-product/20261012-r03-mass-placement-cache/dense-sort-diagnostic.json';
const source = fs.readFileSync(path.join(repo, sourcePath));
const historicalBytes = fs.readFileSync(path.join(repo, historicalPath));
const historical = JSON.parse(historicalBytes);
const L = vm.createContext({Math, JSON, Number, Array, Set});
vm.runInContext(source.toString(), L, {filename:sourcePath});
// The original records encode the right usable endpoint and symmetric token.
// 1853 + 7 = 1860. No original height was saved; Top-only packing is independent
// of height here, so 1080 is explicit rather than claimed historical metadata.
const width = historical.initial.edgeEnd + historical.initial.edgeStart;
const height = 1080, fontScale = 1;
const options = structuredClone(historical.options);
const placements = L.normalize(structuredClone(historical.entries), 'top');
const initialRecords = L.geometry(placements, width, height, options, fontScale);
const initial = initialRecords.find(p => p.id === historical.initial.id);
const initialMatches = ['along','span','edgeStart','edgeEnd'].every(k => initial[k] === historical.initial[k])
  && JSON.stringify(initial.content) === JSON.stringify(historical.initial.content);
if (!initialMatches) throw new Error('Initial geometry does not match saved historical input');
const cases = historical.cases.map(prior => {
  const x = initial.along + initial.span / 2 + prior.dx;
  const y = initial.content.y + initial.content.height / 2;
  const moved = L.checkedMove(placements, initial.id, x, y, width, height,
      {...options, dragEdge:initial.edge}, fontScale, false);
  const records = L.geometry(moved.placements, width, height, options, fontScale);
  const primary = records.find(p => p.id === initial.id);
  const pin = records.find(p => p.id === 'pin');
  const initialPin = initialRecords.find(p => p.id === 'pin');
  const expected = initial.along + prior.dx;
  const result = {dx:prior.dx, requested_center:{x,y}, expected_along:expected,
    actual_along:primary.along, excess_displacement:primary.along-expected,
    total_primary_movement:primary.along-initial.along,
    historical_along:prior.shown, historical_excess:prior.drift,
    rejection:moved.rejected ?? null,
    pin_unchanged:pin.along===initialPin.along && pin.span===initialPin.span,
    placements_unchanged_except_primary:placements.every(p => p.id===initial.id
      || JSON.stringify(p)===JSON.stringify(moved.placements.find(q=>q.id===p.id))),
    peers:records.filter(p=>p.id!==initial.id).map(p=>({id:p.id,along:p.along,span:p.span})),
    records};
  result.matches_historical = Math.abs(result.actual_along-prior.shown)<1e-9
    && Math.abs(result.excess_displacement-prior.drift)<1e-9;
  return result;
});
const sourceAfter = fs.readFileSync(path.join(repo, sourcePath));
const historicalAfter = fs.readFileSync(path.join(repo, historicalPath));
const headAfter = git('rev-parse', 'HEAD').trim();
const immutable = hash(source)===hash(sourceAfter) && hash(historicalBytes)===hash(historicalAfter);
const reproduced = initialMatches && cases.every(c=>c.matches_historical && c.pin_unchanged
  && c.placements_unchanged_except_primary && c.rejection===null);
const metadata = {
  classification:immutable&&reproduced?'PURE_JS_HISTORICAL_REPRODUCED_NOT_NATIVE_OWNER_ACCEPTANCE':'PURE_JS_REPLAY_NOT_MATCHED_OR_SOURCE_CHANGED',
  source_head_before:head, source_head_after:headAfter, origin_dev:git('rev-parse','origin/dev').trim(),
  source_path:sourcePath, source_sha256:hash(source), source_head_blob_sha256:hash(git('show',`${head}:${sourcePath}`)),
  source_origin_blob_sha256:hash(git('show',`origin/dev:${sourcePath}`)),
  historical_path:historicalPath, historical_sha256:hash(historicalBytes),
  runner_sha256:hash(fs.readFileSync(fileURLToPath(import.meta.url))),
  invocation:[process.execPath,fileURLToPath(import.meta.url),repo,output,expectedHead],
  node_version:process.version,
  working_tree:git('status','--short'),
  viewport:{width,height,fontScale,width_provenance:'initial.edgeEnd+initial.edgeStart = 1853+7',
    height_provenance:'not saved historically; explicitly1080; all records Top, no perpendicular collisions'},
  snap:false, immutable_source_and_historical:immutable, initial_geometry_matches_historical:initialMatches,
  all_seven_cases_match_historical:reproduced,
  limits:'Pure production-layout arithmetic only. No QV4, pointer events, render frames, performance or Owner acceptance.'
};
fs.mkdirSync(output);
fs.writeFileSync(path.join(output,'metadata.json'),JSON.stringify(metadata,null,2)+'\n');
fs.writeFileSync(path.join(output,'raw-results.json'),JSON.stringify({initial,initialRecords,options,cases},null,2)+'\n');
fs.writeFileSync(path.join(output,'invocation.json'),JSON.stringify(metadata.invocation,null,2)+'\n');
console.log(JSON.stringify({classification:metadata.classification,source_head:head,source_sha256:metadata.source_sha256,
  origin_same_layout:metadata.source_origin_blob_sha256===metadata.source_sha256,
  cases:cases.map(({dx,expected_along,actual_along,excess_displacement,pin_unchanged})=>
    ({dx,expected_along,actual_along,excess_displacement,pin_unchanged})),output},null,2));
process.exitCode=immutable&&reproduced?0:1;
