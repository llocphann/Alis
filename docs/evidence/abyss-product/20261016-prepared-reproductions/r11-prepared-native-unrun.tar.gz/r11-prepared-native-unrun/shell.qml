pragma ComponentBehavior: Bound
import QtQuick
import QtTest
import Quickshell
import qs
import qs.services
import qs.modules.common
import qs.modules.abyss.bar
import "modules/abyss/looks/AbyssLayout.js" as Layout

ShellRoot {
    id: root
    property string edge: "top"
    property real configuredWidth: 32
    property bool affects: false
    property bool sampling: false
    property string phase: ""
    property int checks: 0
    property int frames: 0
    property var failures: []
    property var traces: []
    property var references: ({})
    property var samples: []
    readonly property var ids: ["first", "custom", "last"]
    Component.onCompleted: Quickshell.watchFiles=false

    FloatingWindow {
        visible: true; implicitWidth: 1000; implicitHeight: 740; color: "#111820"
        Item {
            id: scene; anchors.fill: parent; clip: true
            AbyssBar {
                id: bar; anchors.fill: parent; outputName: "R11-private"; edge: root.edge
                draftPlacements: Layout.normalize([
                    {id:"first",kind:"clock",edge:root.edge,position:.22},
                    {id:"custom",kind:"clock",edge:root.edge,position:.50,customSize:true,size:1.15},
                    {id:"last",kind:"clock",edge:root.edge,position:.78}
                ],root.edge)
                draftOptions: ({edgeThicknesses:{[root.edge]:root.configuredWidth},
                    edgeWidthAffectsModules:{[root.edge]:root.affects}})
            }
        }
    }
    FrameAnimation {
        running: root.sampling
        onTriggered: root.samples=root.samples.concat([test.snapshot()])
    }
    TestCase {
        id: test; when: false; optional: true
        function check(value,label) {
            root.checks++
            if(!value) root.failures=root.failures.concat([root.phase+": "+label])
            return !!value
        }
        function close(a,b,tolerance=.6) { return Math.abs(a-b)<=tolerance }
        function visual(item) {
            const x=Math.max(0,item.x), y=Math.max(0,item.y)
            const right=Math.min(scene.width,item.x+item.width)
            const bottom=Math.min(scene.height,item.y+item.height)
            const visible=item.visible && right>x && bottom>y
            return {x:x,y:y,w:visible?right-x:0,h:visible?bottom-y:0,visible:visible,
                    cross:visible?(["top","bottom"].includes(root.edge)?bottom-y:right-x):0}
        }
        function snapshot() {
            const result={ms:Date.now(),items:{}}
            for(const id of root.ids) {
                const item=bar.itemForId(id)
                if(!item) {result.items[id]=null;continue}
                const r=item.inputRegion
                result.items[id]={visual:visual(item),x:item.x,y:item.y,w:item.width,h:item.height,
                    visible:item.visible,opacity:item.opacity,attachedEdge:item.attachedEdge,
                    region:{x:r.x,y:r.y,w:r.width,h:r.height},
                    sameDelegate:item===root.references[id]?.item,
                    sameFeature:item.feature===root.references[id]?.feature}
            }
            return result
        }
        function sameVisual(a,b,tolerance=.6) {
            if(!a || !b || a.visible!==b.visible) return false
            if(!a.visible) return true
            return ["x","y","w","h"].every(k=>close(a[k],b[k],tolerance))
        }
        function auditSample(sample) {
            for(const id of root.ids) {
                const item=sample.items[id]
                check(item!==null,"delegate disappeared "+id)
                if(!item) continue
                check(item.sameDelegate && item.sameFeature,"resident identity changed "+id)
                check(item.attachedEdge===root.edge,"attachment changed "+id)
                check([item.x,item.y,item.w,item.h].every(Number.isFinite),"non-finite bounds "+id)
                check(item.w>=0 && item.h>=0,"negative dimensions "+id)
                const v=item.visual
                if(id==="custom") {
                    const horizontal=["top","bottom"].includes(root.edge)
                    check(v.visible,"custom-size module blinked during inherited toggle")
                    check(close(horizontal?item.h:item.w,32*Appearance.fontSizeScale*1.15),
                          "inherited toggle changed custom cross size")
                }
                if(v.visible) {
                    check(close(item.opacity,1,.001),"fade substituted for geometry motion "+id)
                    const edgeHalf=root.edge==="top"?v.y+v.h<=scene.height/2
                        :root.edge==="bottom"?v.y>=scene.height/2
                        :root.edge==="left"?v.x+v.w<=scene.width/2:v.x>=scene.width/2
                    check(edgeHalf,"module crossed the workspace instead of its physical Edge "+id)
                }
                const region=item.region
                const expectedW=item.visible?Math.max(0,Math.ceil(item.x+item.w)-Math.floor(item.x)):0
                const expectedH=item.visible?Math.max(0,Math.ceil(item.y+item.h)-Math.floor(item.y)):0
                check(region.x===Math.floor(item.x) && region.y===Math.floor(item.y)
                      && region.w===expectedW && region.h===expectedH,"Region property trails current bounds "+id)
            }
        }
        function endpoint(affects) {
            for(const id of root.ids) {
                const item=bar.itemForId(id),custom=id==="custom"
                const scale=custom?1.15:affects?root.configuredWidth/16:1
                check(item===root.references[id]?.item && item.feature===root.references[id]?.feature,
                      "endpoint replaced resident "+id)
                if(!custom && scale===0) {
                    check(!item.visible && item.inputRegion.width===0 && item.inputRegion.height===0,
                          "configured zero ON must finally hide inherited modules "+id)
                    continue
                }
                check(item.visible,"expected visible endpoint "+id)
                const horizontal=["top","bottom"].includes(root.edge)
                const cross=horizontal?item.height:item.width
                const span=horizontal?item.width:item.height
                check(close(cross,32*Appearance.fontSizeScale*scale),"wrong final cross size "+id)
                check(close(span,item.naturalSpan*scale),"wrong final natural span "+id)
                const gap=root.edge==="top"?item.y:root.edge==="bottom"?scene.height-item.y-item.height
                    :root.edge==="left"?item.x:scene.width-item.x-item.width
                check(close(gap,8),"wrong final physical-edge inset "+id)
            }
        }
        function atEndpoint(affects) {
            for(const id of ["first","last"]) {
                const item=bar.itemForId(id)
                if(!item) return false
                const target=affects?root.configuredWidth/16:1
                if(target===0) { if(item.visible) return false;continue }
                const cross=["top","bottom"].includes(root.edge)?item.height:item.width
                if(!item.visible || !close(cross,32*Appearance.fontSizeScale*target,.1)) return false
            }
            return true
        }
        function capture(label) {
            let finished=false
            check(scene.grabToImage(result=>{
                root.frames++
                check(result.saveToFile(Quickshell.env("ALIS_R11_CAPTURE_DIR")+"/"+label+".png"),"capture save")
                finished=true
            }),"capture refused")
            tryVerify(()=>finished,3000)
        }
        function endTrace(before,to,requireIntermediate=true) {
            const started=Date.now()
            let capturedDuring=false
            while(Date.now()-started<1500 && (Date.now()-started<100 || !atEndpoint(to))) {
                wait(8)
                const current=snapshot().items.first.visual
                if(!capturedDuring && current.visible
                        && !sameVisual(current,before.items.first.visual) && !atEndpoint(to)) {
                    capture(root.phase+"-during")
                    capturedDuring=true
                }
            }
            root.sampling=false
            const after=snapshot()
            root.samples=root.samples.concat([after])
            for(const sample of root.samples) auditSample(sample)
            for(const id of ["first","last"]) {
                const a=before.items[id].visual,b=after.items[id].visual
                const middle=root.samples.filter(s=>s.items[id] && s.items[id].visual.visible
                    && s.items[id].visual.cross>Math.min(a.cross,b.cross)+.6
                    && s.items[id].visual.cross<Math.max(a.cross,b.cross)-.6)
                if(requireIntermediate) {
                    check(middle.length>=2,"no two rendered intermediate bounds "+id)
                    check(middle.some(s=>!close(s.items[id].visual.cross,middle[0].items[id].visual.cross,.1)),
                          "intermediate geometry never advanced "+id)
                }
            }
            endpoint(to)
            root.traces=root.traces.concat([{phase:root.phase,before:before,samples:root.samples,after:after}])
            return after
        }
        function transition(to,label) {
            root.phase=label
            const before=snapshot()
            root.samples=[];root.sampling=true
            root.affects=to
            const immediate=snapshot()
            for(const id of ["first","last"])
                check(sameVisual(before.items[id].visual,immediate.items[id].visual),"synchronous geometry snap "+id)
            return endTrace(before,to)
        }
        function reverse(label) {
            root.phase=label
            const before=snapshot()
            root.samples=[];root.sampling=true;root.affects=true
            const deadline=Date.now()+1000
            while(Date.now()<deadline && !root.samples.some(s=>{
                const v=s.items.first?.visual
                return v?.visible && !close(v.cross,before.items.first.visual.cross,.6)
                    && !atEndpoint(true)
            })) wait(8)
            const pivot=snapshot()
            check(!atEndpoint(true),"reversal was not reached during live motion")
            root.traces=root.traces.concat([{phase:root.phase+"-outbound",before:before,
                                           samples:root.samples,after:pivot}])
            root.samples=[]
            root.affects=false
            const immediate=snapshot()
            for(const id of ["first","last"])
                check(sameVisual(pivot.items[id].visual,immediate.items[id].visual),"reversal reset/jumped bounds "+id)
            endTrace(pivot,false)
        }
        function run() {
            try {
                tryCompare(Config,"ready",true,6000)
                Config.setNestedValues({"panelFamily":"abyss","bar.verbose":false,
                    "abyss.perimeter.thickness":16,"performance.reduceAnimations":true})
                for(const edge of ["top","right","bottom","left"]) for(const width of [0,32]) {
                    root.phase=edge+"-"+width+"-setup"
                    Config.setNestedValue("performance.reduceAnimations",true)
                    root.edge=edge;root.configuredWidth=width;root.affects=false
                    tryVerify(()=>root.ids.every(id=>{
                        const item=bar.itemForId(id)
                        return item!==null && item!==undefined && item.feature!==null
                    }),4000)
                    wait(100)
                    root.references={}
                    for(const id of root.ids) {
                        const item=bar.itemForId(id)
                        root.references[id]={item:item,feature:item.feature}
                    }
                    endpoint(false)
                    capture(edge+"-"+width+"-before")
                    Config.setNestedValue("performance.reduceAnimations",false)
                    tryCompare(Appearance,"animationsEnabled",true,1000)
                    transition(true,edge+"-"+width+"-off-on")
                    transition(false,edge+"-"+width+"-on-off")
                    reverse(edge+"-"+width+"-reversal")
                    capture(edge+"-"+width+"-after")
                    root.phase=edge+"-"+width+"-reduced-motion"
                    Config.setNestedValue("performance.reduceAnimations",true)
                    tryCompare(Appearance,"animationsEnabled",false,1000)
                    root.affects=true;endpoint(true)
                    root.affects=false;endpoint(false)
                }
                console.info("ABYSS_R11_TRACE",JSON.stringify({checks:root.checks,traces:root.traces,failures:root.failures}))
                if(root.failures.length) console.error("ABYSS_R11_WIDTH_TOGGLE_NATIVE_FAIL",root.failures.length,
                                                       JSON.stringify(root.failures.slice(0,32)))
                else console.info("ABYSS_R11_WIDTH_TOGGLE_NATIVE_PASS",root.checks,"checks",root.frames,"captures")
            } catch(error) {
                console.error("ABYSS_R11_WIDTH_TOGGLE_NATIVE_FAIL",error.message,error.stack)
            }
            Qt.quit()
        }
    }
    Timer {interval:100;running:true;onTriggered:test.run()}
}
