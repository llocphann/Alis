# R11 temporary native regression preparation

No native execution has been authorized or performed for this preparation.
This is a regression around the actual production `AbyssBar`, not a copied animation implementation.

Two inherited clock modules and one custom-size clock run on all four physical
edges at configured widths 0 and 32. Frame callbacks sample actual clipped
foreground bounds, delegate/feature identity and Region properties. ON/OFF must
produce at least two distinct intermediate bounds; immediate snaps and opacity
fades fail. Reversal must continue from current geometry. Reduced motion must
reach the correct final geometry immediately. At configured0, ON still hides
inherited modules, and the custom-size module stays visible. The fixture uses
canonical `config/alis`, disables optional Companion/spectrum/waves, and does not
request parent desktop focus or modify owner runtime/configuration.

This does not qualify the Perimeter field/shadows/contact masks, compositor-native
input masks, hover/Popup ownership, editor Save/Cancel, multi-output or Owner
visual acceptance. Existing dedicated tests and later composed checks retain
those responsibilities. It is not a performance benchmark.

Prepare/readback only:

```sh
python3 /tmp/alis-r11-width-toggle-20261016/test-r11-width-toggle-runtime.py --prepare-only --repo /home/llocphann/Shared_Documents/Obsidian-Vault/10_Projects/Alis --expect-sha eca4a41de023083eee86647a0d2fd1abecdfc22e
```

Only after root schedules the native lane, use a fresh output path and the actual
candidate HEAD, preserving original failures as the negative control:

```sh
python3 /tmp/alis-r11-width-toggle-20261016/test-r11-width-toggle-runtime.py --run-native --repo /home/llocphann/Shared_Documents/Obsidian-Vault/10_Projects/Alis --expect-sha EXACT_COMMITTED_SHA --output /tmp/alis-r11-width-toggle-run-UNIQUE
```

The runner refuses an existing output folder, records exact HEAD and affected
file hashes, retains complete native logs/captures, rejects source drift during
the run, bounds Quickshell at90s, and relies on the existing process-group/private
Niri cleanup. Unavailable private Wayland exits77, never PASS.
