#!/usr/bin/env python3
"""Temporary R11 actual-AbyssBar regression; never starts native work by default."""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
mode = parser.add_mutually_exclusive_group(required=True)
mode.add_argument('--prepare-only', action='store_true')
mode.add_argument('--run-native', action='store_true')
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--expect-sha', required=True)
parser.add_argument('--output', type=Path)
args = parser.parse_args()
repo = args.repo.resolve()
head = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip()
branch = subprocess.check_output(['git', '-C', str(repo), 'branch', '--show-current'], text=True).strip()
if branch != 'dev' or head != args.expect_sha:
    raise SystemExit(f'STOP: expected dev/{args.expect_sha}, found {branch}/{head}')
sources = ['modules/abyss/bar/AbyssBar.qml', 'modules/abyss/bar/AbyssBarModule.qml',
           'modules/abyss/looks/AbyssLayout.js', 'modules/common/Appearance.qml',
           'scripts/native_test_session.py', 'defaults/config.json']
manifest = {
    'classification': 'PREPARED_ONLY_NOT_NATIVE_QUALIFICATION',
    'source_sha': head,
    'source_branch': branch,
    'working_tree': subprocess.check_output(['git', '-C', str(repo), 'status', '--short'], text=True),
    'source_sha256': {p: hashlib.sha256((repo / p).read_bytes()).hexdigest() for p in sources},
    'harness_sha256': {p: hashlib.sha256((HERE / p).read_bytes()).hexdigest()
                       for p in ['shell.qml', Path(__file__).name]},
    'scope': 'Actual AbyssBar bounds/identity/Region properties; not Perimeter field, native compositor mask or Owner visual acceptance',
    'final_policy': 'configured width 0 plus Width affects modules ON hides inherited modules; custom modules remain',
}
if args.prepare_only:
    (HERE / 'prepared-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(f'PREPARED_ONLY source={head}; no native process started')
    raise SystemExit(0)
if args.output is None:
    raise SystemExit('STOP: --run-native requires a fresh --output directory under /tmp')
output = args.output.resolve()
if not output.is_relative_to(Path('/tmp')) or output.exists():
    raise SystemExit('STOP: output must be a new directory under /tmp')
output.mkdir(parents=True)
folder = output / 'fixture'
folder.mkdir()
for entry in ['modules', 'services', 'GlobalStates.qml', 'qmldir', 'assets',
              'scripts', 'defaults', 'translations']:
    (folder / entry).symlink_to(repo / entry)
shutil.copy2(HERE / 'shell.qml', folder / 'shell.qml')
config = folder / 'config' / 'alis'
config.mkdir(parents=True)
data = json.loads((repo / 'defaults/config.json').read_text())
data['panelFamily'] = 'abyss'
data['abyss']['companion']['enabled'] = False
data['abyss']['spectrum']['enabled'] = False
data['abyss']['waves']['enabled'] = False
(config / 'config.json').write_text(json.dumps(data))
sys.path.insert(0, str(repo / 'scripts'))
from native_test_session import private_wayland, run_qs

manifest['classification'] = 'RUNNING_NATIVE_REGRESSION_NOT_OWNER_ACCEPTANCE'
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
with private_wayland(folder, capture_focus=False) as env:
    if env is None:
        manifest['classification'] = 'NOT_RUN_PRIVATE_WAYLAND_UNAVAILABLE'
        (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
        raise SystemExit(77)
    env['ALIS_R11_CAPTURE_DIR'] = str(output)
    result = run_qs(folder, env, timeout=90)
(output / 'native.log').write_text(result.stdout)
for line in result.stdout.splitlines():
    if 'ABYSS_R11_TRACE ' in line:
        trace = json.loads(line.split('ABYSS_R11_TRACE ', 1)[1])
        with gzip.open(output / 'trace.json.gz', 'wt') as stream:
            json.dump(trace, stream, separators=(',', ':'))
bad = ['ABYSS_R11_WIDTH_TOGGLE_NATIVE_FAIL', 'TypeError:', 'ReferenceError:',
       'Binding loop', 'Unable to assign', 'Failed to load configuration',
       'is not a type', 'Type unavailable']
passed = (result.returncode == 0 and 'ABYSS_R11_WIDTH_TOGGLE_NATIVE_PASS' in result.stdout
          and not any(token in result.stdout for token in bad))
manifest.update(classification='FOCUSED_NATIVE_PASS_NOT_OWNER_ACCEPTANCE' if passed else 'NATIVE_REGRESSION_FAIL',
                process_exit=result.returncode, native_pass=passed,
                source_after={p: hashlib.sha256((repo / p).read_bytes()).hexdigest() for p in sources})
if manifest['source_after'] != manifest['source_sha256']:
    manifest.update(classification='SOURCE_CHANGED_DURING_RUN_UNQUALIFIED', native_pass=False)
    passed = False
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
for line in result.stdout.splitlines():
    if 'ABYSS_R11_WIDTH_TOGGLE_NATIVE_' in line:
        print(line)
print(f'process_exit={result.returncode}; evidence={output}; native_pass={passed}')
raise SystemExit(0 if passed else 1)
