
pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Window
import QtTest
import Quickshell
import qs
import qs.services
import qs.modules.common
import qs.modules.abyss
import qs.modules.abyss.bar
import qs.modules.abyss.looks
import "modules/abyss/looks/AbyssLayout.js" as Layout
ShellRoot {
 id:root
 property bool showEditor:false
 property var cases:[]
 property int frames:0
 Component.onCompleted:Quickshell.watchFiles=false
 AbyssSurfaceController {id:liquid;outputWidth:scene.width;outputHeight:scene.height;presentationItem:field}
 FloatingWindow {
  visible:true;implicitWidth:1000;implicitHeight:740;color:"#111820"
  Item {
   id:scene;width:850;height:480
   AbyssField {
    id:field;anchors.fill:parent
    boundInterior:true
    renderScale:Window.window?.screen?.devicePixelRatio??1
    records:bar.deformations
    edgeInsets:Layout.edgeInsetsForModules(bar.placements,bar.layoutOptions,Appearance.fontSizeScale,AbyssStyle.perimeterThickness,AbyssStyle.barThickness,false)
    cornerWidthInsets:Layout.edgeInsetsForModules([],bar.layoutOptions,Appearance.fontSizeScale,AbyssStyle.perimeterThickness,AbyssStyle.barThickness,false)
    roundZeroCorners:bar.layoutOptions.edgeRoundZeroCorners
   }
   AbyssBar {
    id:bar;anchors.fill:parent;outputName:"fixture";edge:"top";editing:editor.visible
    draftPlacements:editor.visible?editor.draft:null
    draftOptions:editor.visible?editor.draftOptions:null
    liquidController:liquid
   }
   AbyssEdgeEditor {id:editor;anchors.fill:parent;outputName:"fixture";moduleLayer:bar;controller:liquid;visible:root.showEditor}
  }
 }
 TestCase {
  id:test;when:false;optional:true
  function check(value,message){if(!value)throw new Error(message)}
  function capture(label){
   tryVerify(()=>field.ready,5000);wait(40)
   let done=false
   check(field.grabToImage(result=>{check(result.saveToFile(Quickshell.env("ROUND0_END_OUTPUT")+"/"+label+".png"),"save actual GPU image");done=true;root.frames++}),"capture refused")
   tryVerify(()=>done,5000)
  }
  function run(){try{
   tryCompare(Config,"ready",true,6000)
   Config.setNestedValues({"performance.reduceAnimations":true,"bar.verbose":false,
    "abyss.effects.blur.enabled":false,"abyss.content.blurRadius":0,"abyss.effects.refraction.enabled":false,
    "abyss.surface.opacity":1,"abyss.content.opacity":1,"abyss.effects.shadowStrength":0,
    "abyss.effects.glow.strength":0,"abyss.effects.surfaceHighlight":0,"abyss.waves.enabled":false})
   const saved=JSON.stringify(Config.options.abyss.modules)
   root.showEditor=true;wait(100)
   // Exact reported kinds and retained corner-join direction come first.
   // A zero adjacent paint Edge exposes the weld; the remaining two neighbors
   // stay nonzero. Centered nonjoined controls below test both free endpoints.
   for(const edge of ["left","right"])for(const affects of [false,true]){
    const kind=edge==="left"?"distroIcon":"battery",weldEnd=edge==="left"?"start":"end"
    const comparison=kind+"-"+edge+"-"+(affects?"coupled":"bare")
    editor.editingEdge=edge
    editor.edgeThicknesses=edge==="left"?{top:0,right:16,bottom:24,left:0}:{top:8,right:0,bottom:0,left:32}
    editor.edgeWidthAffectsModules={top:true,right:true,bottom:true,left:true,[edge]:affects}
    editor.edgeModuleRadii={top:-1,right:-1,bottom:-1,left:-1}
    Config.setNestedValue("abyss.perimeter.radius",20)
    for(const joined of [false,true]){
     editor.edgeRoundZeroCorners={top:false,right:false,bottom:false,left:false}
     editor.draft=Layout.normalize([{id:"reported",kind:kind,edge:edge,alignment:weldEnd,
      position:edge==="left"?0:1,joinCorner:joined,customSize:true,size:1,depth:1}],edge)
     tryVerify(()=>bar.deformations.length===1&&editor.layoutConflicts.length===0,5000);wait(120)
     const before=JSON.stringify(bar.deformations),label="reported-"+comparison+"-"+(joined?"joined":"plain")
     capture(label+"-off");editor.edgeRoundZeroCorners={[edge]:true}
     tryVerify(()=>field.physicalContactEdges[edge==="left"?3:1]===true,1000)
     capture(label+"-on")
     check(JSON.stringify(bar.deformations)===before,"reported preview changed during capture")
     check(JSON.stringify(Config.options.abyss.modules)===saved,"reported preview wrote saved settings")
     root.cases.push({label:label,edge:edge,kind:kind,width:scene.width,height:scene.height,curvature:20,
      bodyRadius:AbyssStyle.neckRadius,records:JSON.parse(before),joined:joined,weldEnd:weldEnd,joinComparison:comparison})
    }
   }
   // Start with the owner's actual reported preview kinds/orientations.
   for(const edge of ["left","right","top","bottom"])for(const count of [1,2])for(const curvature of [12,34]){
    const kind=edge==="left"?"distroIcon":edge==="right"?"battery":"clock"
    editor.editingEdge=edge
    editor.edgeThicknesses={top:8,right:16,bottom:24,left:32,[edge]:0}
    editor.edgeJoinModules={top:false,right:false,bottom:false,left:false}
    editor.edgeModuleRadii={top:-1,right:-1,bottom:-1,left:-1}
    editor.draft=Layout.normalize(Array.from({length:count},(_,i)=>({id:"probe"+i,kind:kind,edge:edge,
     position:count===1?.5:i===0?.25:.75,customSize:true,size:i===0?1:.8})),edge)
    Config.setNestedValue("abyss.perimeter.radius",curvature)
    const identities=[]
    for(const affects of [false,true]){
     editor.edgeWidthAffectsModules={top:true,right:true,bottom:true,left:true,[edge]:affects}
     editor.edgeRoundZeroCorners={top:false,right:false,bottom:false,left:false}
     tryVerify(()=>bar.deformations.length===count&&editor.layoutConflicts.length===0,5000);wait(120)
     check(bar.placements.length===count,"valid custom-size module disappeared")
     const current=bar.placements.map(p=>bar.itemForId(p.id))
     if(!identities.length)for(const item of current)identities.push([item,item.feature])
     else for(let i=0;i<current.length;i++)check(current[i]===identities[i][0]&&current[i].feature===identities[i][1],"width-affects toggle recreated module/feature")
     const before=JSON.stringify(bar.deformations)
     const label=kind+"-"+edge+"-"+count+"-"+curvature+"-"+(affects?"coupled":"bare")
     capture(label+"-off")
     editor.edgeRoundZeroCorners={[edge]:true}
     const at=["top","right","bottom","left"].indexOf(edge)
     tryVerify(()=>field.physicalContactEdges[at]===true,1000)
     check(field.cornerWidthInsets[edge]===0,"draft configured width did not reach field")
     capture(label+"-on")
     check(JSON.stringify(bar.deformations)===before,"capture pair changed actual backing geometry")
     check(JSON.stringify(Config.options.abyss.modules)===saved,"transient preview changed saved module settings")
     root.cases.push({label:label,edge:edge,kind:kind,width:scene.width,height:scene.height,curvature:curvature,
      bodyRadius:AbyssStyle.neckRadius,records:JSON.parse(before)})
    }
   }
   console.info("ROUND0_MODULE_END_CASES",JSON.stringify(root.cases))
   console.info("ROUND0_MODULE_END_NATIVE_PASS",root.cases.length,"scenes",root.frames,"actual GPU images")
  }catch(error){console.error("ROUND0_MODULE_END_FAIL",error.message,error.stack)}Qt.quit()}
 }
 Timer {interval:100;running:true;onTriggered:test.run()}
}
