from pathlib import Path
p=Path('/tmp/alis-r11-width-toggle-candidate/source')
layout=p/'modules/abyss/looks/AbyssLayout.js'
s=layout.read_text()
old='function edgeInsetsForModules(placements, options, fontScale, thickness, minimum, reservation) {\n'
assert s.count(old)==1
s=s.replace(old,old+'    if (placements.length && options?._widthFrame)\n        return Object.assign({},reservation ? options._widthFrame.reservationInsets : options._widthFrame.paintInsets);\n',1)
s+=r'''

// Width-mode animation owns one plain-data frame. Configuration and the physical
// zero-width corner gate remain separate from its transient foreground geometry.
function widthFrame(placements,width,height,options,fontScale,minimum,radius,support) {
    var saved=Object.assign({},options);
    delete saved._widthFrame;
    var records=geometry(placements,width,height,saved,fontScale);
    return {records:records,deformations:localSurfaces(records,width,height,saved,fontScale,minimum),
        paintInsets:edgeInsetsForModules(placements,saved,fontScale,saved.edgeThickness,minimum,false),
        reservationInsets:edgeInsetsForModules(placements,saved,fontScale,saved.edgeThickness,minimum,true),
        options:saved,width:width,height:height,radius:radius,support:support};
}
function widthMix(a,b,t) { return a+(b-a)*t; }
function widthRect(a,b,t) {
    return {x:widthMix(a.x,b.x,t),y:widthMix(a.y,b.y,t),
        width:widthMix(a.width,b.width,t),height:widthMix(a.height,b.height,t)};
}
function widthPoint(record,frame,surface) {
    var r=surface ? record.surface : record.content;
    var x=r.x+r.width/2,y=r.y+r.height/2,d=frame.support;
    if(record.edge==="top")y=-d;
    else if(record.edge==="bottom")y=frame.height+d;
    else if(record.edge==="left")x=-d;
    else x=frame.width+d;
    return {x:x,y:y,width:0,height:0};
}
function widthCollapsed(record,frame,surface) {
    var result=Object.assign({},record),point=widthPoint(record,frame,surface);
    result.content=point;result.span=0;result.depth=0;
    result.along=record.edge==="top" || record.edge==="bottom" ? point.x : point.y;
    if(surface){result.surface=point;result.radius=0;}
    return result;
}
function widthRecord(a,b,t,frame,surface) {
    var result=Object.assign({},b),horizontal=b.edge==="top" || b.edge==="bottom";
    result.content=widthRect(a.content,b.content,t);
    result.along=widthMix(a.along,b.along,t);
    result.span=widthMix(a.span,b.span,t);
    result.depth=widthMix(a.depth,b.depth,t);
    if(surface) {
        result.surface=widthRect(a.surface,b.surface,t);
        result.radius=widthMix(a.radius ?? frame.radius,b.radius ?? frame.radius,t);
    }
    return result;
}
function widthMembers(shape,records) {
    return records.filter(function(r) {
        return r.edge===shape.edge && r.along+r.span/2>=shape.along-0.01
            && r.along+r.span/2<=shape.along+shape.span+0.01;
    }).map(function(r){return r.id;});
}
function widthFrameBetween(from,to,t) {
    if(t<=0)return from;
    if(t>=1)return to;
    var ids=from.records.map(function(r){return r.id;});
    to.records.forEach(function(r){if(ids.indexOf(r.id)<0)ids.push(r.id);});
    var records=ids.map(function(id) {
        var a=from.records.find(function(r){return r.id===id;});
        var b=to.records.find(function(r){return r.id===id;});
        return widthRecord(a || widthCollapsed(b,to,false),b || widthCollapsed(a,to,false),t,to,false);
    });
    // One source owner per backing: duplicating a joined shape changes the
    // ordered smooth union even when the duplicate rectangles are identical.
    var used=[],shapes=from.deformations.map(function(a) {
        var members=widthMembers(a,from.records);
        var index=to.deformations.findIndex(function(b,i) {
            return used.indexOf(i)<0 && widthMembers(b,to.records).some(function(id){return members.indexOf(id)>=0;});
        });
        if(index>=0)used.push(index);
        var b=index>=0 ? to.deformations[index] : widthCollapsed(a,to,true);
        return widthRecord(a,b,t,to,true);
    });
    to.deformations.forEach(function(b,i) {
        if(used.indexOf(i)<0)shapes.push(widthRecord(widthCollapsed(b,to,true),b,t,to,true));
    });
    var paint={},reservation={};
    ["top","right","bottom","left"].forEach(function(edge) {
        paint[edge]=widthMix(from.paintInsets[edge],to.paintInsets[edge],t);
        reservation[edge]=widthMix(from.reservationInsets[edge],to.reservationInsets[edge],t);
    });
    return {records:records,deformations:shapes,paintInsets:paint,reservationInsets:reservation,
        options:to.options,width:to.width,height:to.height,radius:to.radius,support:to.support};
}
'''
layout.write_text(s)
bar=p/'modules/abyss/bar/AbyssBar.qml';s=bar.read_text()
old='    readonly property var layoutOptions: Object.assign({},draftOptions ?? Layout.optionsForOutput(Config.options?.abyss?.modules,outputName),{extents:measuredExtents,editing:editing,edgeThickness:AbyssStyle.perimeterThickness,cornerRadius:AbyssStyle.perimeterRadius})'
assert s.count(old)==1
s=s.replace(old,r'''    readonly property var configuredLayoutOptions: Object.assign({},draftOptions ?? Layout.optionsForOutput(Config.options?.abyss?.modules,outputName),{extents:measuredExtents,editing:editing,edgeThickness:AbyssStyle.perimeterThickness,cornerRadius:AbyssStyle.perimeterRadius})
    readonly property var layoutOptions: Object.assign({},configuredLayoutOptions,
        widthMorphActive ? {_widthFrame:presentedFrame} : {})
    property var targetFrame: null
    property var fromFrame: null
    property real widthProgress: 1
    property bool frameReady: false
    property string widthModeKey: ""
    readonly property bool widthMorphActive: fromFrame!==null && widthProgress<1
    readonly property var presentedFrame: widthMorphActive
        ? Layout.widthFrameBetween(fromFrame,targetFrame,widthProgress) : targetFrame
    readonly property var presentedLayoutRecords: presentedFrame?.records ?? []
    function captureWidthFrame(): var {
        return Object.assign({},presentedFrame,{records:renderedRecords,deformations:deformations})
    }
    function refreshWidthFrame(): void {
        if(width<=0 || height<=0)return
        const next=Layout.widthFrame(placements,width,height,configuredLayoutOptions,
            Appearance.fontSizeScale,AbyssStyle.barThickness,AbyssStyle.neckRadius,
            AbyssStyle.perimeterRadius+AbyssStyle.neckRadius+AbyssStyle.connectionDepth+32)
        const key=JSON.stringify(["top","right","bottom","left"].map(edge=>configuredLayoutOptions.edgeWidthAffectsModules?.[edge]!==false))
        const animate=frameReady && Config.ready && visible && AbyssStyle.motionEnabled
            && targetFrame!==null && key!==widthModeKey
        const previous=animate ? captureWidthFrame() : null
        widthMotion.stop()
        widthModeKey=key
        if(animate){fromFrame=previous;widthProgress=0;targetFrame=next;widthMotion.restart()}
        else {fromFrame=null;widthProgress=1;targetFrame=next}
    }
    function finishWidthMorph(): void {
        if(widthMorphActive){widthMotion.complete();widthProgress=1;fromFrame=null}
    }
    NumberAnimation {
        id:widthMotion;target:root;property:"widthProgress";from:0;to:1
        duration:AbyssStyle.motionNormal;easing.type:Easing.OutCubic
        onFinished:root.fromFrame=null
    }
    onConfiguredLayoutOptionsChanged:refreshWidthFrame()
    onWidthChanged:refreshWidthFrame()
    onHeightChanged:refreshWidthFrame()
    onVisibleChanged:if(!visible)finishWidthMorph()
    Connections {
        target:Appearance
        function onAnimationsEnabledChanged(){if(!Appearance.animationsEnabled)root.finishWidthMorph()}
        function onFontSizeScaleChanged(){root.refreshWidthFrame()}
    }
    Connections {
        target:AbyssStyle
        function onMotionEnabledChanged(){if(!AbyssStyle.motionEnabled)root.finishWidthMorph()}
    }''',1)
s=s.replace('readonly property var layoutRecords: Layout.geometry(placements,width,height,layoutOptions,Appearance.fontSizeScale)','readonly property var layoutRecords: targetFrame?.records ?? []',1)
s=s.replace('return layoutRecords.map(record=>{','return presentedLayoutRecords.map(record=>{',1)
s=s.replace('readonly property var deformations: Layout.localSurfaces(renderedRecords.concat(capacityNotices),width,height,layoutOptions,Appearance.fontSizeScale,AbyssStyle.barThickness)','readonly property var deformations: widthMorphActive ? presentedFrame.deformations : Layout.localSurfaces(renderedRecords.concat(capacityNotices),width,height,targetFrame?.options ?? configuredLayoutOptions,Appearance.fontSizeScale,AbyssStyle.barThickness)',1)
s=s.replace('onPlacementsChanged: syncModuleIds()','onPlacementsChanged: {syncModuleIds();refreshWidthFrame()}',1)
s=s.replace('Component.onCompleted: syncModuleIds()','Component.onCompleted: {syncModuleIds();refreshWidthFrame();frameReady=true}',1)
s=s.replace('readonly property var geometry: root.layoutRecords.find(rec => rec.id === modelData)','readonly property var geometry: root.presentedLayoutRecords.find(rec => rec.id === modelData)',1)
s=s.replace('readonly property bool animatePlacement: motionReady','readonly property bool animatePlacement: !root.widthMorphActive && motionReady',1)
bar.write_text(s)
per=p/'modules/abyss/AbyssPerimeter.qml';s=per.read_text()
# Variants' actual native output instances own the live frame; no global map.
import re
variant=re.search(r'Variants\s*\{\s*id:\s*(\w+)',s).group(1)
needle='        const options=Object.assign({},ModuleLayout.optionsForOutput(Config.options?.abyss?.modules,name),{edgeThickness:AbyssStyle.perimeterThickness})'
assert s.count(needle)==1
s=s.replace(needle,'        const live='+variant+'.instances.find(window=>window?.outputName===name)?.widthModuleLayer\n        const options=live?.layoutOptions ?? Object.assign({},ModuleLayout.optionsForOutput(Config.options?.abyss?.modules,name),{edgeThickness:AbyssStyle.perimeterThickness})',1)
needle='        const placements = ModuleLayout.resolve(Config.options?.abyss?.modules,name,ModuleLayout.seed(zones,root.barEdge,screen?.width ?? 1920,screen?.height ?? 1080))'
assert s.count(needle)==1
s=s.replace(needle,'        const placements = live?.placements ?? ModuleLayout.resolve(Config.options?.abyss?.modules,name,ModuleLayout.seed(zones,root.barEdge,screen?.width ?? 1920,screen?.height ?? 1080))',1)
needle='            id: window\n';assert s.count(needle)==1
s=s.replace(needle,needle+'            property alias widthModuleLayer: bar\n',1)
per.write_text(s)
print('PRIVATE WIP written: Bar/Layout/Perimeter; native UNRUN')
